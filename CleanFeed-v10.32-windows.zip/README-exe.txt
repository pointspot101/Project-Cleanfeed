CLEAN FEED v10.32 — Windows 실행 파일

1. CleanFeed-v10.32.exe 를 더블클릭합니다.
2. 게임 파일이 %LOCALAPPDATA%\CleanFeed\clean-feed.html 로 풀리고,
   Microsoft Edge(없으면 Chrome, 둘 다 없으면 기본 브라우저)의 앱 창으로 열립니다.
3. 진행 기록은 그 브라우저에 저장됩니다. 같은 PC에서 다시 실행하면 이어서 할 수 있습니다.

* 코드 서명이 없는 파일이라 처음 실행할 때 Windows SmartScreen 경고가 뜰 수 있습니다.
  "추가 정보" → "실행"을 누르면 실행됩니다.
* 설치·관리자 권한이 필요 없고, 인터넷 연결이 없어도 실행됩니다.
